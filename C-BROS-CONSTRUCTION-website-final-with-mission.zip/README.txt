C-BROS CONSTRUCTION WEBSITE — UPDATED VERSION

Your supplied logo and 9 project photos are included.
Open index.html to preview the site.

For free hosting, upload this folder to GitHub Pages, Netlify, or Cloudflare Pages.
The site is static HTML/CSS and needs no paid software.

Included project images:
- Pinaripad Bridge
- Disiluad Bridge
- Philippine Navy Multipurpose Hall
- Dibibi-Tucod National Road (multiple segments)
- Mapacopaco Flood Control
- Alfonso Lista Flood Control
